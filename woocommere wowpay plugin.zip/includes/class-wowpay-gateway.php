<?php
if (!defined('ABSPATH')) {
    exit;
}

class WC_WowPay_Gateway extends WC_Payment_Gateway {
    public function __construct() {
        $this->id = 'wowpay';
        $this->icon = apply_filters('wowpay_wc_icon', '');
        $this->has_fields = false;
        $this->method_title = __('WowPay', 'wowpay-woocommerce');
        $this->method_description = __('Accept payments via WowPay payment gateway.', 'wowpay-woocommerce');

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();

        // Define user set variables
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->app_id = $this->get_option('app_id');
        $this->app_secret = $this->get_option('app_secret');
        $this->testmode = 'yes' === $this->get_option('testmode');
        $this->debug = 'yes' === $this->get_option('debug');
        $this->webhook_url = home_url('/wowpay-webhook');

        // Actions
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_api_wc_wowpay_gateway', array($this, 'check_response'));
        add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));

        // Webhook handler
        $this->webhook_handler = new WC_WowPay_Webhook_Handler($this);
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => __('Enable/Disable', 'wowpay-woocommerce'),
                'type' => 'checkbox',
                'label' => __('Enable WowPay Payment Gateway', 'wowpay-woocommerce'),
                'default' => 'yes'
            ),
            'title' => array(
                'title' => __('Title', 'wowpay-woocommerce'),
                'type' => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'wowpay-woocommerce'),
                'default' => __('WowPay', 'wowpay-woocommerce'),
                'desc_tip' => true,
            ),
            'description' => array(
                'title' => __('Description', 'wowpay-woocommerce'),
                'type' => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'wowpay-woocommerce'),
                'default' => __('Pay securely through WowPay.', 'wowpay-woocommerce'),
                'desc_tip' => true,
            ),
            'app_id' => array(
                'title' => __('App ID', 'wowpay-woocommerce'),
                'type' => 'text',
                'description' => __('Enter your WowPay Application ID.', 'wowpay-woocommerce'),
                'default' => '',
                'desc_tip' => true,
            ),
            'app_secret' => array(
                'title' => __('App Secret', 'wowpay-woocommerce'),
                'type' => 'password',
                'description' => __('Enter your WowPay Application Secret Key.', 'wowpay-woocommerce'),
                'default' => '',
                'desc_tip' => true,
            ),
            'testmode' => array(
                'title' => __('Test Mode', 'wowpay-woocommerce'),
                'type' => 'checkbox',
                'label' => __('Enable Test Mode', 'wowpay-woocommerce'),
                'default' => 'no',
                'description' => __('Place the payment gateway in test mode using test API keys.', 'wowpay-woocommerce'),
            ),
            'debug' => array(
                'title' => __('Debug Log', 'wowpay-woocommerce'),
                'type' => 'checkbox',
                'label' => __('Enable logging', 'wowpay-woocommerce'),
                'default' => 'no',
                'description' => sprintf(
                    __('Log WowPay events, such as API requests and webhooks, inside %s', 'wowpay-woocommerce'),
                    '<code>' . WC_Log_Handler_File::get_log_file_path('wowpay') . '</code>'
                ),
            ),
        );
    }

    public function process_payment($order_id) {
        $order = wc_get_order($order_id);

        return array(
            'result' => 'success',
            'redirect' => $order->get_checkout_payment_url(true)
        );
    }

    public function receipt_page($order_id) {
        $order = wc_get_order($order_id);
        $amount = $order->get_total();
        $currency = $order->get_currency();
        
        // Generate unique order ID
        $orderid = $order_id . '_' . time();
        
        // Calculate signature
        $sign = md5(strtolower($this->app_id . $this->app_secret));
        
        // Prepare request data
        $request_data = array(
            'appid' => $this->app_id,
            'app_secret' => $this->app_secret,
            'orderid' => $orderid,
            'amount' => number_format($amount, 2, '.', ''),
            'time' => time(),
            'sign' => $sign
        );
        
        // Log request
        $this->log('Request to WowPay API: ' . print_r($request_data, true));
        
        // Send request to WowPay
        $response = wp_remote_post('https://wowpay.cfd/api/payment', array(
            'method' => 'POST',
            'body' => $request_data,
            'timeout' => 45
        ));
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            $this->log('Error: ' . $error_message);
            wc_add_notice(__('Payment error:', 'wowpay-woocommerce') . $error_message, 'error');
            return;
        }
        
        $response_body = wp_remote_retrieve_body($response);
        $result = json_decode($response_body, true);
        
        $this->log('Response from WowPay API: ' . print_r($result, true));
        
        if (isset($result['status']) && $result['status'] === 'success') {
            // Store payment ID in order meta
            $order->update_meta_data('_wowpay_payment_id', $result['payment_id']);
            $order->update_meta_data('_wowpay_order_id', $orderid);
            $order->save();
            
            // Redirect to WowPay payment page
            wp_redirect($result['url']);
            exit;
        } else {
            $error_message = isset($result['message']) ? $result['message'] : __('Unknown error occurred', 'wowpay-woocommerce');
            $this->log('Error: ' . $error_message);
            wc_add_notice(__('Payment error:', 'wowpay-woocommerce') . $error_message, 'error');
            return;
        }
    }

    public function log($message) {
        if ($this->debug) {
            $logger = wc_get_logger();
            $logger->debug($message, array('source' => 'wowpay'));
        }
    }
}