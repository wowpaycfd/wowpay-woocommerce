<?php
if (!defined('ABSPATH')) {
    exit;
}

class WC_WowPay_Webhook_Handler {
    protected $gateway;

    public function __construct($gateway) {
        $this->gateway = $gateway;
        add_action('woocommerce_api_wowpay-webhook', array($this, 'handle_webhook'));
    }

    public function handle_webhook() {
        $headers = getallheaders();
        $signature = isset($headers['X-WowPay-Signature']) ? $headers['X-WowPay-Signature'] : '';
        $timestamp = isset($headers['X-WowPay-Timestamp']) ? $headers['X-WowPay-Timestamp'] : '';
        $payload = file_get_contents('php://input');
        
        $this->gateway->log('Webhook received: ' . $payload);
        $this->gateway->log('Headers: ' . print_r($headers, true));
        
        // Verify timestamp (5-minute window)
        if (abs(time() - $timestamp) > 300) {
            $this->gateway->log('Webhook Error: Expired request');
            wp_send_json_error('Expired request', 400);
            exit;
        }
        
        // Verify signature
        $expected = hash_hmac('sha256', $timestamp.$payload, $this->gateway->app_secret);
        if (!hash_equals($expected, $signature)) {
            $this->gateway->log('Webhook Error: Invalid signature');
            wp_send_json_error('Invalid signature', 401);
            exit;
        }
        
        $data = json_decode($payload, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->gateway->log('Webhook Error: Invalid JSON payload');
            wp_send_json_error('Invalid JSON payload', 400);
            exit;
        }
        
        $this->process_webhook($data);
        
        wp_send_json(array(
            'status' => 'success',
            'message' => 'Webhook processed'
        ));
    }

    protected function process_webhook($data) {
        if (!isset($data['orderid']) || !isset($data['status'])) {
            $this->gateway->log('Webhook Error: Missing required data');
            return;
        }
        
        // Extract original order ID from the WowPay order ID
        $order_id_parts = explode('_', $data['orderid']);
        $order_id = $order_id_parts[0];
        
        $order = wc_get_order($order_id);
        
        if (!$order) {
            $this->gateway->log('Webhook Error: Order not found');
            return;
        }
        
        // Check if this order was processed already
        if ($order->get_meta('_wowpay_webhook_processed', true)) {
            $this->gateway->log('Webhook: Order already processed');
            return;
        }
        
        $this->gateway->log('Processing webhook for order #' . $order_id . ' with status: ' . $data['status']);
        
        switch ($data['status']) {
            case 'success':
                $order->add_order_note(__('WowPay payment completed.', 'wowpay-woocommerce'));
                $order->payment_complete();
                $order->update_meta_data('_wowpay_webhook_processed', true);
                $order->save();
                break;
                
            case 'failed':
                $order->add_order_note(__('WowPay payment failed.', 'wowpay-woocommerce'));
                $order->update_status('failed');
                $order->update_meta_data('_wowpay_webhook_processed', true);
                $order->save();
                break;
                
            case 'pending':
                $order->add_order_note(__('WowPay payment is pending.', 'wowpay-woocommerce'));
                $order->update_status('pending');
                $order->save();
                break;
                
            default:
                $this->gateway->log('Webhook: Unknown status received: ' . $data['status']);
                break;
        }
    }
}