<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Add custom query vars for webhook
 */
function wowpay_wc_add_query_vars($vars) {
    $vars[] = 'wowpay-webhook';
    return $vars;
}
add_filter('query_vars', 'wowpay_wc_add_query_vars');

/**
 * Handle webhook request
 */
function wowpay_wc_handle_webhook() {
    global $wp;
    
    if (isset($wp->query_vars['wowpay-webhook'])) {
        $gateways = WC()->payment_gateways->payment_gateways();
        
        if (isset($gateways['wowpay'])) {
            $gateway = $gateways['wowpay'];
            $webhook_handler = new WC_WowPay_Webhook_Handler($gateway);
            $webhook_handler->handle_webhook();
        }
        
        exit;
    }
}
add_action('parse_request', 'wowpay_wc_handle_webhook');

/**
 * Display payment ID in admin order page
 */
function wowpay_wc_display_order_meta($order) {
    $payment_id = $order->get_meta('_wowpay_payment_id');
    if ($payment_id) {
        echo '<p><strong>' . __('WowPay Payment ID:') . '</strong> ' . esc_html($payment_id) . '</p>';
    }
}
add_action('woocommerce_admin_order_data_after_billing_address', 'wowpay_wc_display_order_meta', 10, 1);