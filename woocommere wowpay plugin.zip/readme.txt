=== WooCommerce WowPay Gateway ===
Contributors: Chinuchai
Website link: https://wowpay.cfd
Tags: woocommerce, payment gateway, wowpay, credit card, debit card
Requires at least: WordPress 5.6, WooCommerce 5.0
Tested up to: WordPress 6.3, WooCommerce 7.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Accept payments through WowPay payment gateway in your WooCommerce store.

== Description ==

This plugin integrates the WowPay payment gateway with WooCommerce, allowing you to accept secure payments from your customers.

Key Features:
- Secure payment processing via WowPay
- Real-time payment status updates via webhooks
- Test mode for development and testing
- Detailed logging for troubleshooting
- Simple configuration through WooCommerce settings

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/wowpay-woocommerce` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Configure the plugin in WooCommerce → Settings → Payments → WowPay
4. Enter your WowPay App ID and App Secret
5. Configure webhook URL in your WowPay Merchant Dashboard: `[your-site-url]/wowpay-webhook`

== Frequently Asked Questions ==

= Where do I get my WowPay API credentials? =
You can get your App ID and App Secret from your WowPay merchant dashboard after registering an account.

= How do I test the payment gateway? =
Enable Test Mode in the plugin settings. Use test credentials provided by WowPay.

= How do I troubleshoot issues? =
Enable Debug Log in the plugin settings. Logs can be found in WooCommerce → Status → Logs (select 'wowpay' from the dropdown).

= The payments aren't processing, what should I do? =
1. Verify your API credentials are correct
2. Check that your server can communicate with WowPay's API (https://wowpay.cfd/api/payment)
3. Ensure your webhook URL is properly configured in WowPay dashboard
4. Check the debug logs for any errors

== Screenshots ==
1. WooCommerce payment settings screen showing WowPay configuration
2. Checkout page showing WowPay payment option
3. Order details page showing WowPay payment information

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release of the plugin.